﻿namespace BasicConsoleApp;

public class LogEvents
{
    public const int UserBirthday = 5001;
}
